package com.dbs.project.LoanProposalProject.service;

import com.dbs.project.LoanProposalProject.model.Customer;

public class CustomerService {

	
	
	public CustomerService() {
		System.out.println("Customer service");
	}
	
	public Customer findCustomerByEmail(String email)
	{
		return null;
		
	}
	
	public boolean addCustomer(Customer customer) {
		
		return true;
	}
	
}
